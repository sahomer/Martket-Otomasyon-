const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Helpers ---
const dataPath = (file) => path.join(__dirname, 'data', file);
const readJSON = (file) => JSON.parse(fs.readFileSync(dataPath(file), 'utf-8'));
const writeJSON = (file, data) => fs.writeFileSync(dataPath(file), JSON.stringify(data, null, 2), 'utf-8');
const nextId = (arr) => arr.length ? Math.max(...arr.map(i => i.id)) + 1 : 1;

// ============ AUTH ============
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const users = readJSON('users.json');
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Geçersiz kullanıcı adı veya şifre' });
  res.json({ id: user.id, name: user.name, role: user.role });
});

// ============ PRODUCTS ============
app.get('/api/products', (req, res) => res.json(readJSON('products.json')));

app.get('/api/products/:barcode', (req, res) => {
  const products = readJSON('products.json');
  const p = products.find(x => x.barcode === req.params.barcode);
  if (!p) return res.status(404).json({ error: 'Ürün bulunamadı' });
  res.json(p);
});

app.post('/api/products', (req, res) => {
  const products = readJSON('products.json');
  const p = { id: nextId(products), ...req.body };
  products.push(p);
  writeJSON('products.json', products);
  res.json(p);
});

app.put('/api/products/:id', (req, res) => {
  const products = readJSON('products.json');
  const idx = products.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Ürün bulunamadı' });
  products[idx] = { ...products[idx], ...req.body };
  writeJSON('products.json', products);
  res.json(products[idx]);
});

app.delete('/api/products/:id', (req, res) => {
  let products = readJSON('products.json');
  products = products.filter(x => x.id !== parseInt(req.params.id));
  writeJSON('products.json', products);
  res.json({ success: true });
});

// ============ SALES ============
app.get('/api/sales', (req, res) => res.json(readJSON('sales.json')));

app.post('/api/sales', (req, res) => {
  const sales = readJSON('sales.json');
  const products = readJSON('products.json');
  const sale = { id: nextId(sales), date: new Date().toISOString(), ...req.body };

  // Update stock
  if (sale.items) {
    sale.items.forEach(item => {
      const pIdx = products.findIndex(p => p.id === item.productId);
      if (pIdx !== -1) {
        products[pIdx].stock = Math.max(0, products[pIdx].stock - item.quantity);
      }
    });
    writeJSON('products.json', products);
  }

  // If veresiye, add to customer balance
  if (sale.paymentMethod === 'veresiye' && sale.customerId) {
    const customers = readJSON('customers.json');
    const cIdx = customers.findIndex(c => c.id === sale.customerId);
    if (cIdx !== -1) {
      customers[cIdx].balance += sale.total;
      customers[cIdx].transactions.push({
        date: sale.date.split('T')[0],
        type: 'debt',
        amount: sale.total,
        description: 'Satış #' + sale.id
      });
      writeJSON('customers.json', customers);
    }
  }

  sales.push(sale);
  writeJSON('sales.json', sales);
  res.json(sale);
});

// ============ CUSTOMERS ============
app.get('/api/customers', (req, res) => res.json(readJSON('customers.json')));

app.post('/api/customers', (req, res) => {
  const customers = readJSON('customers.json');
  const c = { id: nextId(customers), balance: 0, transactions: [], ...req.body };
  customers.push(c);
  writeJSON('customers.json', customers);
  res.json(c);
});

app.put('/api/customers/:id', (req, res) => {
  const customers = readJSON('customers.json');
  const idx = customers.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Müşteri bulunamadı' });
  customers[idx] = { ...customers[idx], ...req.body };
  writeJSON('customers.json', customers);
  res.json(customers[idx]);
});

app.delete('/api/customers/:id', (req, res) => {
  let customers = readJSON('customers.json');
  customers = customers.filter(x => x.id !== parseInt(req.params.id));
  writeJSON('customers.json', customers);
  res.json({ success: true });
});

app.post('/api/customers/:id/payment', (req, res) => {
  const customers = readJSON('customers.json');
  const idx = customers.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Müşteri bulunamadı' });
  const { amount, description } = req.body;
  customers[idx].balance = Math.max(0, customers[idx].balance - amount);
  customers[idx].transactions.push({
    date: new Date().toISOString().split('T')[0],
    type: 'payment',
    amount,
    description: description || 'Tahsilat'
  });
  writeJSON('customers.json', customers);
  res.json(customers[idx]);
});

// ============ SUPPLIERS ============
app.get('/api/suppliers', (req, res) => res.json(readJSON('suppliers.json')));

app.post('/api/suppliers', (req, res) => {
  const suppliers = readJSON('suppliers.json');
  const s = { id: nextId(suppliers), balance: 0, transactions: [], ...req.body };
  suppliers.push(s);
  writeJSON('suppliers.json', suppliers);
  res.json(s);
});

app.put('/api/suppliers/:id', (req, res) => {
  const suppliers = readJSON('suppliers.json');
  const idx = suppliers.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Tedarikçi bulunamadı' });
  suppliers[idx] = { ...suppliers[idx], ...req.body };
  writeJSON('suppliers.json', suppliers);
  res.json(suppliers[idx]);
});

app.delete('/api/suppliers/:id', (req, res) => {
  let suppliers = readJSON('suppliers.json');
  suppliers = suppliers.filter(x => x.id !== parseInt(req.params.id));
  writeJSON('suppliers.json', suppliers);
  res.json({ success: true });
});

app.post('/api/suppliers/:id/payment', (req, res) => {
  const suppliers = readJSON('suppliers.json');
  const idx = suppliers.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Tedarikçi bulunamadı' });
  const { amount, description, paymentMethod } = req.body;
  suppliers[idx].balance = Math.max(0, suppliers[idx].balance - amount);
  suppliers[idx].transactions.push({
    date: new Date().toISOString().split('T')[0],
    type: 'payment',
    amount,
    description: description || 'Ödeme',
    paymentMethod: paymentMethod || 'nakit'
  });
  writeJSON('suppliers.json', suppliers);
  res.json(suppliers[idx]);
});

app.post('/api/suppliers/:id/invoice', (req, res) => {
  const suppliers = readJSON('suppliers.json');
  const idx = suppliers.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Tedarikçi bulunamadı' });
  const { amount, description } = req.body;
  suppliers[idx].balance += amount;
  suppliers[idx].transactions.push({
    date: new Date().toISOString().split('T')[0],
    type: 'invoice',
    amount,
    description: description || 'Fatura'
  });
  writeJSON('suppliers.json', suppliers);
  res.json(suppliers[idx]);
});

// ============ USERS ============
app.get('/api/users', (req, res) => res.json(readJSON('users.json')));

app.post('/api/users', (req, res) => {
  const users = readJSON('users.json');
  const u = { id: nextId(users), ...req.body };
  users.push(u);
  writeJSON('users.json', users);
  res.json(u);
});

app.put('/api/users/:id', (req, res) => {
  const users = readJSON('users.json');
  const idx = users.findIndex(x => x.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  users[idx] = { ...users[idx], ...req.body };
  writeJSON('users.json', users);
  res.json(users[idx]);
});

app.delete('/api/users/:id', (req, res) => {
  let users = readJSON('users.json');
  users = users.filter(x => x.id !== parseInt(req.params.id));
  writeJSON('users.json', users);
  res.json({ success: true });
});

// ============ INVENTORY COUNT ============
app.post('/api/inventory/count', (req, res) => {
  const products = readJSON('products.json');
  const { counts } = req.body; // [{productId, physicalCount}]
  const results = [];
  counts.forEach(c => {
    const idx = products.findIndex(p => p.id === c.productId);
    if (idx !== -1) {
      const diff = products[idx].stock - c.physicalCount;
      results.push({
        product: products[idx].name,
        systemStock: products[idx].stock,
        physicalCount: c.physicalCount,
        difference: diff
      });
      products[idx].stock = c.physicalCount;
    }
  });
  writeJSON('products.json', products);
  res.json({ results });
});

// ============ REPORTS ============
app.get('/api/reports/daily', (req, res) => {
  const sales = readJSON('sales.json');
  const today = new Date().toISOString().split('T')[0];
  const todaySales = sales.filter(s => s.date && s.date.startsWith(today));
  const totalRevenue = todaySales.reduce((sum, s) => sum + (s.total || 0), 0);
  const cashTotal = todaySales.filter(s => s.paymentMethod === 'nakit').reduce((sum, s) => sum + (s.total || 0), 0);
  const cardTotal = todaySales.filter(s => s.paymentMethod === 'kart').reduce((sum, s) => sum + (s.total || 0), 0);
  const veresiyeTotal = todaySales.filter(s => s.paymentMethod === 'veresiye').reduce((sum, s) => sum + (s.total || 0), 0);
  res.json({
    date: today,
    salesCount: todaySales.length,
    totalRevenue,
    cashTotal,
    cardTotal,
    veresiyeTotal
  });
});

app.get('/api/reports/profit', (req, res) => {
  const sales = readJSON('sales.json');
  const products = readJSON('products.json');
  let totalProfit = 0;
  let totalRevenue = 0;
  let totalCost = 0;
  sales.forEach(sale => {
    if (sale.items) {
      sale.items.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (product) {
          totalRevenue += item.sellPrice * item.quantity;
          totalCost += product.buyPrice * item.quantity;
        }
      });
    }
  });
  totalProfit = totalRevenue - totalCost;
  res.json({ totalRevenue, totalCost, totalProfit });
});

app.get('/api/reports/top-products', (req, res) => {
  const sales = readJSON('sales.json');
  const products = readJSON('products.json');
  const counts = {};
  sales.forEach(sale => {
    if (sale.items) {
      sale.items.forEach(item => {
        counts[item.productId] = (counts[item.productId] || 0) + item.quantity;
      });
    }
  });
  const sorted = Object.entries(counts)
    .map(([id, qty]) => {
      const p = products.find(x => x.id === parseInt(id));
      return { name: p ? p.name : 'Bilinmeyen', quantity: qty };
    })
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 10);
  res.json(sorted);
});

// Catch-all: serve login page
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));

app.listen(PORT, () => {
  console.log(`Market Otomasyon Sistemi çalışıyor: http://localhost:${PORT}`);
});
